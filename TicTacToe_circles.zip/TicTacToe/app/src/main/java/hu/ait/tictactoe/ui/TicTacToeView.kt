package hu.ait.tictactoe.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class TicTacToeView(context: Context, attributeSet: AttributeSet): View(context, attributeSet) {

    var paintBackground = Paint()
    var paintLine = Paint()

    var x = -1
    var y = -1

    private var circles = mutableListOf<PointF>() //To store the coordinates of the circles

    init {
        paintBackground.color = Color.BLACK
        paintBackground.style = Paint.Style.FILL

        paintLine.color = Color. WHITE
        paintLine.style = Paint.Style.STROKE
        paintLine.strokeWidth = 5f
    }

    override fun onDraw(canvas: Canvas?) {

        canvas?.drawRect(0f,0f, width.toFloat(), height.toFloat(), paintBackground)
        canvas?.drawLine(0f, 0f, width.toFloat(), height.toFloat(), paintLine)

        for (circle in circles) {
            canvas?.drawCircle(circle.x, circle.y, 60f, paintLine)
        }
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if(event?.action == MotionEvent.ACTION_DOWN){ // ACTION_MOVE then can hold and move

            circles.add(PointF(event?.x, event?.y))

            invalidate() // redraws the view, by calling onDraw() eventually....
        }

        return true
    }

    public fun restart(){
        circles.clear()
        invalidate()
    }

}